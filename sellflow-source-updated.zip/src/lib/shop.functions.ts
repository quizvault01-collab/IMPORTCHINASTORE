import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const orderSchema = z.object({
  shopSlug: z.string().trim().min(1).max(40),
  customer_name: z.string().trim().min(2).max(80),
  customer_phone: z.string().trim().min(6).max(30),
  delivery_address: z.string().trim().min(3).max(300),
  note: z.string().trim().max(500).nullable().optional(),
  operator: z.enum(["airtel", "moov"]),
  items: z
    .array(z.object({ product_id: z.string().uuid(), quantity: z.number().int().min(1).max(99) }))
    .min(1)
    .max(30),
});

export const getShopBySlug = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => z.object({ slug: z.string().trim().max(40) }).parse(input))
  .handler(async ({ data }) => {
    const { createPublicClient } = await import("./shop.server");
    const supabase = createPublicClient();
    const { data: vendor, error } = await supabase
      .from("vendors")
      .select(
        "id, shop_name, shop_slug, owner_name, category, description, logo_url, banner_url, brand_color, mobile_money_operator, status",
      )
      .eq("shop_slug", data.slug)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!vendor) return null;

    const { data: products } = await supabase
      .from("products")
      .select("id, name, description, price, stock_quantity, image_url")
      .eq("vendor_id", vendor.id)
      .eq("is_active", true)
      .order("created_at", { ascending: false });

    return { vendor, products: products ?? [] };
  });

export const placeOrder = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => orderSchema.parse(input))
  .handler(async ({ data }) => {
    const { createOrderForShop } = await import("./shop.server");
    return createOrderForShop(data);
  });
