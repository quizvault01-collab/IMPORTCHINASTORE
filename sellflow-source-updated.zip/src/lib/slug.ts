export function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
}

export function formatFcfa(amount: number): string {
  return `${new Intl.NumberFormat("fr-FR").format(Math.round(amount))} FCFA`;
}

export const CATEGORIES = [
  "telephones",
  "vetements",
  "chaussures",
  "cosmetiques",
  "parfums",
  "bijouterie",
  "accessoires",
  "autre",
] as const;

export const CATEGORY_LABELS: Record<string, string> = {
  telephones: "Téléphones",
  vetements: "Vêtements",
  chaussures: "Chaussures",
  cosmetiques: "Cosmétiques",
  parfums: "Parfums",
  bijouterie: "Bijouterie",
  accessoires: "Accessoires",
  autre: "Autre",
};

export const ORDER_STATUS_LABELS: Record<string, string> = {
  en_attente: "En attente",
  confirme: "Confirmée",
  expedie: "Expédiée",
  livre: "Livrée",
  annule: "Annulée",
};

export const PAYMENT_STATUS_LABELS: Record<string, string> = {
  en_attente: "Paiement en attente",
  paye: "Payée",
  echoue: "Paiement échoué",
};
