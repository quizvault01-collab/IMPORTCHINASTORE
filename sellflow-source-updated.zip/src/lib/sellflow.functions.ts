import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const vendorProfileSchema = z.object({
  shop_name: z.string().trim().min(2).max(60),
  shop_slug: z
    .string()
    .trim()
    .min(2)
    .max(40)
    .regex(/^[a-z0-9-]+$/),
  owner_name: z.string().trim().max(80).default(""),
  owner_phone: z.string().trim().max(30).default(""),
  category: z.string().trim().max(30).default("autre"),
  description: z.string().trim().max(500).nullable().optional(),
  logo_url: z.string().trim().max(500).nullable().optional(),
  banner_url: z.string().trim().max(500).nullable().optional(),
  brand_color: z
    .string()
    .trim()
    .regex(/^#[0-9a-fA-F]{6}$/)
    .default("#0E7A5F"),
  mobile_money_operator: z.enum(["airtel", "moov"]).nullable().optional(),
  ref: z.string().trim().max(40).nullable().optional(),
});

const productSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().trim().min(1).max(100),
  description: z.string().trim().max(1000).nullable().optional(),
  price: z.number().int().min(0).max(100_000_000),
  stock_quantity: z.number().int().min(0).max(1_000_000),
  image_url: z.string().trim().max(1000).nullable().optional(),
  is_active: z.boolean().default(true),
});

export const getMyVendor = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("vendors")
      .select("*")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  });

export const saveVendor = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => vendorProfileSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { ref, ...profile } = data;

    let referred_by: string | null = null;
    if (ref) {
      const { data: affiliate } = await context.supabase
        .from("affiliates")
        .select("id")
        .eq("code", ref)
        .maybeSingle();
      referred_by = affiliate?.id ?? null;
    }

    const { data: existing } = await context.supabase
      .from("vendors")
      .select("id")
      .eq("user_id", context.userId)
      .maybeSingle();

    if (existing) {
      const { data: updated, error } = await context.supabase
        .from("vendors")
        .update(profile)
        .eq("id", existing.id)
        .select("*")
        .single();
      if (error) throw new Error(error.message);
      return updated;
    }

    const { data: created, error } = await context.supabase
      .from("vendors")
      .insert({ ...profile, user_id: context.userId, referred_by })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return created;
  });

export const listMyProducts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("products")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const saveProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => productSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: vendor } = await context.supabase
      .from("vendors")
      .select("id")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!vendor) throw new Error("Boutique introuvable");

    const { id, ...values } = data;
    if (id) {
      const { data: updated, error } = await context.supabase
        .from("products")
        .update(values)
        .eq("id", id)
        .select("*")
        .single();
      if (error) throw new Error(error.message);
      return updated;
    }
    const { data: created, error } = await context.supabase
      .from("products")
      .insert({ ...values, vendor_id: vendor.id })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return created;
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("products").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listMyOrders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("orders")
      .select("*, order_items(*)")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const updateOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(["en_attente", "confirme", "expedie", "livre", "annule"]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("orders")
      .update({ status: data.status })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
