// Couche d'abstraction paiement Mobile Money.
// Une implémentation par fournisseur : on pourra brancher K-PAY sans toucher
// à la logique de commande.

export type GatewayName = "geniuspay" | "kpay" | "simulation";

export interface PaymentInitiation {
  orderId: string;
  orderNumber: string;
  amount: number;
  customerPhone: string;
  operator: "airtel" | "moov";
}

export interface PaymentResult {
  success: boolean;
  gateway: GatewayName;
  reference: string | null;
  message: string;
}

export interface PaymentGatewayInterface {
  name: GatewayName;
  supports(operator: "airtel" | "moov"): boolean;
  initiate(payload: PaymentInitiation): Promise<PaymentResult>;
}

/**
 * GeniusPay — Airtel Money uniquement (1% + 100 XOF).
 * Doc API : https://pay.genius.ci/docs/api
 * Limites connues : transaction min 100 FCFA, max 2 000 000 FCFA.
 * Règlement : paiement validé en 24-72h ouvrées, retrait manuel en 24-48h ouvrées supplémentaires
 * (donc PAS instantané — à communiquer clairement au vendeur).
 */
class GeniusPayGateway implements PaymentGatewayInterface {
  name: GatewayName = "geniuspay";
  private static readonly BASE_URL = "https://pay.genius.ci/api/v1";
  private static readonly MIN_AMOUNT = 100;
  private static readonly MAX_AMOUNT = 2_000_000;

  supports(operator: "airtel" | "moov") {
    return operator === "airtel";
  }

  async initiate(payload: PaymentInitiation): Promise<PaymentResult> {
    const apiKey = process.env.GENIUSPAY_API_KEY;
    const apiSecret = process.env.GENIUSPAY_API_SECRET;

    if (!apiKey || !apiSecret) {
      return simulate(payload, "geniuspay");
    }

    if (payload.amount < GeniusPayGateway.MIN_AMOUNT || payload.amount > GeniusPayGateway.MAX_AMOUNT) {
      return {
        success: false,
        gateway: "geniuspay",
        reference: null,
        message: `Montant hors limites GeniusPay (${GeniusPayGateway.MIN_AMOUNT}-${GeniusPayGateway.MAX_AMOUNT} FCFA)`,
      };
    }

    try {
      const response = await fetch(`${GeniusPayGateway.BASE_URL}/merchant/payments`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-API-Key": apiKey,
          "X-API-Secret": apiSecret,
        },
        body: JSON.stringify({
          amount: payload.amount,
          gateway: "airtel",
          customer: { phone: payload.customerPhone },
          metadata: { order_id: payload.orderId, order_number: payload.orderNumber },
        }),
      });

      const json = await response.json();

      if (!response.ok || !json.success) {
        return {
          success: false,
          gateway: "geniuspay",
          reference: json?.data?.reference ?? null,
          message: json?.message ?? "Échec de l'initiation du paiement GeniusPay",
        };
      }

      return {
        success: json.data.status === "completed" || json.data.status === "pending",
        gateway: "geniuspay",
        reference: json.data.reference,
        message:
          json.data.status === "pending"
            ? "Paiement en attente de confirmation par le client (Mobile Money)"
            : "Paiement initié avec succès",
      };
    } catch (err) {
      return {
        success: false,
        gateway: "geniuspay",
        reference: null,
        message: `Erreur réseau GeniusPay : ${err instanceof Error ? err.message : "inconnue"}`,
      };
    }
  }
}

/** K-PAY — Airtel + Moov (3%). À activer quand un besoin Moov est confirmé. */
class KPayGateway implements PaymentGatewayInterface {
  name: GatewayName = "kpay";
  supports() {
    return true;
  }
  async initiate(payload: PaymentInitiation): Promise<PaymentResult> {
    return simulate(payload, "kpay");
  }
}

async function simulate(payload: PaymentInitiation, gateway: GatewayName): Promise<PaymentResult> {
  return {
    success: true,
    gateway,
    reference: `SIM-${gateway.toUpperCase()}-${payload.orderNumber}`,
    message:
      "Paiement simulé (aucun identifiant fournisseur configuré). Le vendeur doit confirmer la réception des fonds.",
  };
}

const geniusPay = new GeniusPayGateway();
const kPay = new KPayGateway();

export function resolveGateway(operator: "airtel" | "moov"): PaymentGatewayInterface {
  if (geniusPay.supports(operator)) return geniusPay;
  return kPay;
}

export function isGatewayLive(): boolean {
  return Boolean(process.env.GENIUSPAY_API_KEY);
}

/**
 * Vérifie qu'un webhook entrant vient bien de GeniusPay (signature HMAC), pas d'un tiers
 * qui essaierait de faire croire à un paiement réussi. À adapter dès que GeniusPay documente
 * précisément son schéma de signature (header exact, algorithme) — squelette prêt en attendant.
 */
export function verifyGeniusPaySignature(rawBody: string, signatureHeader: string | null): boolean {
  const secret = process.env.GENIUSPAY_WEBHOOK_SECRET;
  if (!secret || !signatureHeader) return false;
  const crypto = require("node:crypto");
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signatureHeader));
  } catch {
    return false; // longueurs différentes = signature invalide
  }
}
