import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { resolveGateway, isGatewayLive } from "./payments/gateway.server";

export function createPublicClient() {
  const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
  return createClient<Database>(process.env.SUPABASE_URL!, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

export interface OrderPayload {
  shopSlug: string;
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  note?: string | null;
  operator: "airtel" | "moov";
  items: { product_id: string; quantity: number }[];
}

export async function createOrderForShop(payload: OrderPayload) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: vendor } = await supabaseAdmin
    .from("vendors")
    .select("id, shop_name, status, mobile_money_operator")
    .eq("shop_slug", payload.shopSlug)
    .maybeSingle();

  if (!vendor || vendor.status === "suspended") {
    throw new Error("Boutique indisponible");
  }
  if (!vendor.mobile_money_operator) {
    throw new Error("Cette boutique n'a pas encore configuré son paiement Mobile Money");
  }
  if (payload.operator !== vendor.mobile_money_operator) {
    throw new Error("Opérateur non disponible pour cette boutique");
  }

  const ids = payload.items.map((i) => i.product_id);
  const { data: products } = await supabaseAdmin
    .from("products")
    .select("id, name, price, stock_quantity, is_active")
    .eq("vendor_id", vendor.id)
    .in("id", ids);

  const lines = payload.items.map((item) => {
    const product = products?.find((p) => p.id === item.product_id);
    if (!product || !product.is_active) throw new Error("Un produit du panier n'est plus disponible");
    if (product.stock_quantity < item.quantity) throw new Error(`Stock insuffisant : ${product.name}`);
    return {
      product_id: product.id,
      product_name: product.name,
      unit_price: product.price,
      quantity: item.quantity,
    };
  });

  // Les prix sont toujours relus en base : jamais ceux envoyés par le navigateur.
  const total = lines.reduce((sum, l) => sum + l.unit_price * l.quantity, 0);

  const { data: order, error } = await supabaseAdmin
    .from("orders")
    .insert({
      vendor_id: vendor.id,
      customer_name: payload.customer_name,
      customer_phone: payload.customer_phone,
      delivery_address: payload.delivery_address,
      note: payload.note ?? null,
      total_amount: total,
      mobile_money_operator: payload.operator,
    })
    .select("id, order_number, total_amount, commission_amount")
    .single();
  if (error) throw new Error(error.message);

  await supabaseAdmin
    .from("order_items")
    .insert(lines.map((l) => ({ ...l, order_id: order.id })));

  // Réserve le stock immédiatement et atomiquement (évite qu'une vente simultanée
  // ne survende un produit entre la lecture du stock plus haut et cette écriture).
  for (const line of lines) {
    const { data: ok, error: stockError } = await supabaseAdmin.rpc("decrement_stock", {
      _product_id: line.product_id,
      _quantity: line.quantity,
    });
    if (stockError || !ok) {
      await supabaseAdmin.from("orders").update({ status: "annule" }).eq("id", order.id);
      throw new Error(`Stock insuffisant (vente concurrente) : ${line.product_name}`);
    }
  }

  const gateway = resolveGateway(payload.operator);
  const payment = await gateway.initiate({
    orderId: order.id,
    orderNumber: order.order_number,
    amount: order.total_amount,
    customerPhone: payload.customer_phone,
    operator: payload.operator,
  });

  // Important : GeniusPay confirme le paiement de façon asynchrone (le client valide
  // sur son téléphone après coup). "success" ici veut dire "initié sans erreur", pas
  // "argent reçu" — la confirmation finale arrive via /webhooks/geniuspay.
  // En mode simulation (pas de clé API), on marque payé tout de suite pour pouvoir tester.
  const isSimulated = !isGatewayLive();
  await supabaseAdmin
    .from("orders")
    .update({
      payment_gateway: payment.gateway,
      payment_reference: payment.reference,
      payment_status: isSimulated ? (payment.success ? "paye" : "echoue") : "en_attente",
      status: isSimulated && payment.success ? "confirme" : "en_attente",
    })
    .eq("id", order.id);

  if (!payment.success) {
    // Le paiement n'a même pas pu être initié : on relibère le stock réservé plus haut.
    for (const line of lines) {
      await supabaseAdmin.rpc("increment_stock", { _product_id: line.product_id, _quantity: line.quantity });
    }
  }

  return {
    order_number: order.order_number,
    total: order.total_amount,
    commission: order.commission_amount,
    shop_name: vendor.shop_name,
    payment_message: payment.message,
    simulated: !isGatewayLive(),
  };
}
