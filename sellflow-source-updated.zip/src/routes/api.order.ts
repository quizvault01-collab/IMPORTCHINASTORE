import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { z } from "zod";

// Endpoint REST simple pour la page boutique HTML statique (public/boutique.html).
// Reprend exactement la même logique que placeOrder (src/lib/shop.functions.ts),
// juste exposée en JSON brut au lieu d'un server function React.

const orderSchema = z.object({
  shopSlug: z.string().trim().min(1).max(40),
  customer_name: z.string().trim().min(2).max(80),
  customer_phone: z.string().trim().min(6).max(30),
  delivery_address: z.string().trim().min(3).max(300),
  note: z.string().trim().max(500).nullable().optional(),
  operator: z.enum(["airtel", "moov"]),
  items: z
    .array(z.object({ product_id: z.string().uuid(), quantity: z.number().int().min(1).max(99) }))
    .min(1)
    .max(30),
});

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export const Route = createFileRoute("/api/order")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS_HEADERS }),

      POST: async ({ request }) => {
        let json: unknown;
        try {
          json = await request.json();
        } catch {
          return new Response(JSON.stringify({ error: "JSON invalide" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...CORS_HEADERS },
          });
        }

        const parsed = orderSchema.safeParse(json);
        if (!parsed.success) {
          return new Response(JSON.stringify({ error: parsed.error.issues[0]?.message ?? "Requête invalide" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...CORS_HEADERS },
          });
        }

        try {
          const { createOrderForShop } = await import("@/lib/shop.server");
          const result = await createOrderForShop(parsed.data);
          return new Response(JSON.stringify(result), {
            status: 200,
            headers: { "Content-Type": "application/json", ...CORS_HEADERS },
          });
        } catch (err) {
          return new Response(
            JSON.stringify({ error: err instanceof Error ? err.message : "Erreur inconnue" }),
            { status: 400, headers: { "Content-Type": "application/json", ...CORS_HEADERS } },
          );
        }
      },
    },
  },
});
