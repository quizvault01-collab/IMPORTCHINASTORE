import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const searchSchema = z.object({ ref: z.string().max(40).optional() });

export const Route = createFileRoute("/auth")({
  validateSearch: (search) => searchSchema.parse(search),
  head: () => ({
    meta: [
      { title: "Connexion vendeur — SellFlow" },
      {
        name: "description",
        content: "Connecte-toi ou crée ton compte vendeur SellFlow pour ouvrir ta boutique.",
      },
      { property: "og:title", content: "Connexion vendeur — SellFlow" },
      { property: "og:description", content: "Accède à ton espace vendeur SellFlow." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { ref } = Route.useSearch();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (ref) localStorage.setItem("sellflow_ref", ref);
  }, [ref]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/tableau-de-bord", replace: true });
    });
  }, [navigate]);

  async function signIn() {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return toast.error(error.message);
    navigate({ to: "/tableau-de-bord" });
  }

  async function signUp() {
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/tableau-de-bord` },
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Compte créé — vérifie ta boîte mail si une confirmation est demandée.");
    navigate({ to: "/ma-boutique" });
  }

  async function google() {
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) return toast.error("Connexion Google impossible pour le moment.");
    if (result.redirected) return;
    navigate({ to: "/tableau-de-bord" });
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-hero px-4 py-10">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-6 block text-center font-display text-2xl font-bold text-primary">
          SellFlow
        </Link>
        <Card className="shadow-elevated">
          <CardHeader>
            <CardTitle className="text-center text-lg">Espace vendeur</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signup">
              <TabsList className="mb-4 grid w-full grid-cols-2">
                <TabsTrigger value="signup">Créer un compte</TabsTrigger>
                <TabsTrigger value="signin">Se connecter</TabsTrigger>
              </TabsList>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Mot de passe</Label>
                  <Input
                    id="password"
                    type="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>

                <TabsContent value="signup" className="m-0">
                  <Button className="w-full" disabled={loading} onClick={signUp}>
                    Créer ma boutique
                  </Button>
                </TabsContent>
                <TabsContent value="signin" className="m-0">
                  <Button className="w-full" disabled={loading} onClick={signIn}>
                    Se connecter
                  </Button>
                </TabsContent>

                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="h-px flex-1 bg-border" /> ou <span className="h-px flex-1 bg-border" />
                </div>

                <Button variant="outline" className="w-full" onClick={google}>
                  Continuer avec Google
                </Button>
              </div>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
