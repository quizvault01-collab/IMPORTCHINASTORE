import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { formatFcfa } from "@/lib/slug";
import {
  Smartphone,
  Store,
  Wallet,
  Share2,
  ShieldCheck,
  BarChart3,
  ArrowRight,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SellFlow — Ta boutique en ligne au Gabon en 10 minutes" },
      {
        name: "description",
        content:
          "Crée ta boutique en ligne, encaisse par Mobile Money et gère tes commandes. 0 FCFA à l'inscription, 5% de commission uniquement sur les ventes.",
      },
      { property: "og:title", content: "SellFlow — Ta boutique en ligne au Gabon" },
      {
        property: "og:description",
        content:
          "Vends sur WhatsApp et Facebook avec un vrai lien de boutique et le paiement Mobile Money.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <span className="font-display text-xl font-bold text-primary">SellFlow</span>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/auth">Se connecter</Link>
            </Button>
            <Button size="sm" asChild>
              <Link to="/auth">Créer ma boutique</Link>
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="bg-gradient-hero">
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 md:grid-cols-2 md:items-center md:py-24">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-accent/15 px-3 py-1 text-xs font-semibold text-accent-foreground">
                <ShieldCheck className="size-3.5" /> Fait pour les commerçants gabonais
              </span>
              <h1 className="mt-4 font-display text-4xl font-bold leading-tight md:text-5xl">
                Ta boutique en ligne, prête en 10 minutes.
              </h1>
              <p className="mt-4 max-w-lg text-base text-muted-foreground">
                Arrête de gérer tes ventes uniquement en messages privés. SellFlow te donne un lien
                de boutique, un catalogue propre et le paiement Airtel Money automatique.
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <Button variant="hero" size="lg" asChild>
                  <Link to="/auth">
                    Commencer gratuitement <ArrowRight />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <a href="#tarifs">Voir les tarifs</a>
                </Button>
              </div>
              <p className="mt-4 text-xs text-muted-foreground">
                Inscription gratuite · Commission de 5% seulement quand tu vends
              </p>
            </div>

            <Card className="shadow-elevated">
              <CardContent className="space-y-4 py-6">
                <p className="text-sm font-semibold">Exemple de vente</p>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Panier client</span>
                  <span className="font-semibold">{formatFcfa(50000)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Commission SellFlow (5%)</span>
                  <span className="font-semibold">-{formatFcfa(2500)}</span>
                </div>
                <div className="flex justify-between border-t border-border pt-3 text-base">
                  <span className="font-semibold">Tu reçois</span>
                  <span className="font-display font-bold text-primary">{formatFcfa(47500)}</span>
                </div>
                <p className="rounded-lg bg-secondary p-3 text-xs text-muted-foreground">
                  Paiement encaissé par Mobile Money, reversé sur ton numéro marchand.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="font-display text-2xl font-bold">Tout ce qu'il te faut pour vendre</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: <Store />,
                title: "Boutique personnalisée",
                text: "Nom, logo, bannière, couleur et lien unique à partager partout.",
              },
              {
                icon: <Smartphone />,
                title: "Paiement Mobile Money",
                text: "Airtel Money intégré. Moov Money arrive très bientôt.",
              },
              {
                icon: <Wallet />,
                title: "Commission simple",
                text: "5% par vente. Aucun abonnement, aucun frais caché.",
              },
              {
                icon: <BarChart3 />,
                title: "Suivi des commandes",
                text: "Confirme, expédie, livre : chaque commande suit un statut clair.",
              },
              {
                icon: <Share2 />,
                title: "Pensé pour WhatsApp",
                text: "Un lien propre qui remplace les captures d'écran de catalogue.",
              },
              {
                icon: <ShieldCheck />,
                title: "Données protégées",
                text: "Chaque vendeur ne voit que ses propres produits et commandes.",
              },
            ].map((f) => (
              <Card key={f.title} className="shadow-soft">
                <CardContent className="space-y-2 py-6">
                  <span className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    {f.icon}
                  </span>
                  <h3 className="font-semibold">{f.title}</h3>
                  <p className="text-sm text-muted-foreground">{f.text}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section id="tarifs" className="bg-secondary/50 py-16">
          <div className="mx-auto max-w-3xl px-4 text-center">
            <h2 className="font-display text-2xl font-bold">Un seul tarif, sans surprise</h2>
            <Card className="mt-8 text-left shadow-elevated">
              <CardContent className="space-y-4 py-8">
                <p className="font-display text-4xl font-bold text-primary">5%</p>
                <p className="text-sm text-muted-foreground">
                  prélevés uniquement sur les commandes payées. Création de boutique, catalogue
                  illimité, gestion des commandes et lien de partage inclus.
                </p>
                <Button variant="hero" size="lg" asChild>
                  <Link to="/auth">Ouvrir ma boutique</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-8">
        <div className="mx-auto max-w-6xl px-4 text-sm text-muted-foreground">
          <span className="font-display font-bold text-primary">SellFlow</span> — Libreville, Gabon
        </div>
      </footer>
    </div>
  );
}
