import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { getMyVendor, listMyOrders, listMyProducts } from "@/lib/sellflow.functions";
import { formatFcfa, ORDER_STATUS_LABELS } from "@/lib/slug";
import { Copy, TrendingUp, ShoppingBag, Wallet, Package } from "lucide-react";

export const Route = createFileRoute("/_authenticated/tableau-de-bord")({
  head: () => ({
    meta: [
      { title: "Tableau de bord vendeur — SellFlow" },
      {
        name: "description",
        content: "Chiffre d'affaires, commandes et produits populaires de ta boutique SellFlow.",
      },
      { property: "og:title", content: "Tableau de bord vendeur — SellFlow" },
      {
        property: "og:description",
        content: "Suis tes ventes Mobile Money et tes commandes en temps réel.",
      },
    ],
  }),
  component: DashboardPage,
});

type Period = 7 | 30 | 365;

function DashboardPage() {
  const navigate = useNavigate();
  const [period, setPeriod] = useState<Period>(30);

  const vendorQuery = useQuery({ queryKey: ["vendor"], queryFn: useServerFn(getMyVendor) });
  const ordersQuery = useQuery({ queryKey: ["orders"], queryFn: useServerFn(listMyOrders) });
  const productsQuery = useQuery({ queryKey: ["products"], queryFn: useServerFn(listMyProducts) });

  const vendor = vendorQuery.data;
  const orders = ordersQuery.data ?? [];

  const stats = useMemo(() => {
    const since = Date.now() - period * 24 * 60 * 60 * 1000;
    const scoped = orders.filter((o) => new Date(o.created_at).getTime() >= since);
    const paid = scoped.filter((o) => o.payment_status === "paye");
    const revenue = paid.reduce((s, o) => s + o.total_amount, 0);
    const commission = paid.reduce((s, o) => s + o.commission_amount, 0);
    const counts = new Map<string, number>();
    for (const order of paid) {
      for (const item of order.order_items ?? []) {
        counts.set(item.product_name, (counts.get(item.product_name) ?? 0) + item.quantity);
      }
    }
    const top = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
    return { count: scoped.length, revenue, commission, net: revenue - commission, top };
  }, [orders, period]);

  const setupMutation = useMutation({
    mutationFn: async () => navigate({ to: "/ma-boutique" }),
  });

  if (vendorQuery.isLoading) {
    return (
      <AppShell>
        <Skeleton className="h-40 w-full" />
      </AppShell>
    );
  }

  if (!vendor) {
    return (
      <AppShell>
        <Card className="mx-auto max-w-lg text-center shadow-soft">
          <CardHeader>
            <CardTitle>Crée ta boutique</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Encore une étape : donne un nom à ta boutique et choisis ton opérateur Mobile Money.
            </p>
            <Button onClick={() => setupMutation.mutate()}>Configurer ma boutique</Button>
          </CardContent>
        </Card>
      </AppShell>
    );
  }

  const shopUrl =
    typeof window !== "undefined" ? `${window.location.origin}/boutique/${vendor.shop_slug}` : "";

  return (
    <AppShell>
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Bonjour {vendor.owner_name || vendor.shop_name}</h1>
          <p className="text-sm text-muted-foreground">
            Voici l'activité de <span className="font-medium text-foreground">{vendor.shop_name}</span>.
          </p>
        </div>
        <div className="flex gap-1 rounded-lg bg-secondary p-1">
          {([7, 30, 365] as Period[]).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                period === p ? "bg-background shadow-soft" : "text-muted-foreground"
              }`}
            >
              {p === 7 ? "7 jours" : p === 30 ? "30 jours" : "12 mois"}
            </button>
          ))}
        </div>
      </div>

      {!vendor.mobile_money_operator && (
        <Card className="mb-6 border-warning/50 bg-warning/10">
          <CardContent className="flex flex-wrap items-center justify-between gap-3 py-4">
            <p className="text-sm font-medium">
              Ta boutique n'est pas encore publiable : choisis ton opérateur Mobile Money.
            </p>
            <Button size="sm" onClick={() => navigate({ to: "/ma-boutique" })}>
              Compléter
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={<TrendingUp />} label="Chiffre d'affaires" value={formatFcfa(stats.revenue)} />
        <StatCard icon={<ShoppingBag />} label="Commandes" value={String(stats.count)} />
        <StatCard
          icon={<Wallet />}
          label="Commission SellFlow (5%)"
          value={formatFcfa(stats.commission)}
        />
        <StatCard icon={<Package />} label="Net vendeur" value={formatFcfa(stats.net)} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Dernières commandes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {orders.slice(0, 6).map((order) => (
              <div
                key={order.id}
                className="flex items-center justify-between gap-3 rounded-lg border border-border/70 p-3"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{order.customer_name}</p>
                  <p className="text-xs text-muted-foreground">{order.order_number}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">{formatFcfa(order.total_amount)}</p>
                  <Badge variant="secondary" className="text-[10px]">
                    {ORDER_STATUS_LABELS[order.status]}
                  </Badge>
                </div>
              </div>
            ))}
            {orders.length === 0 && (
              <p className="py-6 text-center text-sm text-muted-foreground">
                Aucune commande pour l'instant. Partage le lien de ta boutique !
              </p>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle className="text-base">Lien de ta boutique</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="break-all rounded-md bg-secondary p-3 text-xs">{shopUrl}</p>
              <Button
                variant="soft"
                className="w-full"
                onClick={() => {
                  navigator.clipboard.writeText(shopUrl);
                  toast.success("Lien copié — partage-le sur WhatsApp");
                }}
              >
                <Copy /> Copier le lien
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle className="text-base">Produits populaires</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {stats.top.length === 0 && (
                <p className="text-sm text-muted-foreground">Pas encore de ventes.</p>
              )}
              {stats.top.map(([name, qty]) => (
                <div key={name} className="flex items-center justify-between text-sm">
                  <span className="truncate">{name}</span>
                  <span className="font-semibold">{qty}</span>
                </div>
              ))}
              <p className="pt-2 text-xs text-muted-foreground">
                {(productsQuery.data ?? []).length} produit(s) en catalogue
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}

function StatCard({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <Card className="shadow-soft">
      <CardContent className="flex items-center gap-3 py-5">
        <span className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
          {icon}
        </span>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="truncate text-lg font-bold">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}
