import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { listMyOrders, updateOrderStatus } from "@/lib/sellflow.functions";
import { formatFcfa, ORDER_STATUS_LABELS, PAYMENT_STATUS_LABELS } from "@/lib/slug";

export const Route = createFileRoute("/_authenticated/commandes")({
  head: () => ({
    meta: [
      { title: "Mes commandes — SellFlow" },
      {
        name: "description",
        content: "Suis chaque commande : paiement Mobile Money, statut de livraison et commission.",
      },
      { property: "og:title", content: "Mes commandes — SellFlow" },
      {
        property: "og:description",
        content: "Confirme, expédie et livre tes commandes depuis un seul écran.",
      },
    ],
  }),
  component: OrdersPage,
});

const STATUSES = ["en_attente", "confirme", "expedie", "livre", "annule"] as const;

function OrdersPage() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<string>("tous");
  const ordersQuery = useQuery({ queryKey: ["orders"], queryFn: useServerFn(listMyOrders) });
  const update = useServerFn(updateOrderStatus);

  const mutation = useMutation({
    mutationFn: async (input: { id: string; status: (typeof STATUSES)[number] }) =>
      update({ data: input }),
    onSuccess: () => {
      toast.success("Statut mis à jour");
      queryClient.invalidateQueries({ queryKey: ["orders"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const orders = (ordersQuery.data ?? []).filter(
    (o) => filter === "tous" || o.status === filter,
  );

  return (
    <AppShell>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Commandes</h1>
          <p className="text-sm text-muted-foreground">{orders.length} commande(s) affichée(s)</p>
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="tous">Tous les statuts</SelectItem>
            {STATUSES.map((s) => (
              <SelectItem key={s} value={s}>
                {ORDER_STATUS_LABELS[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        {orders.map((order) => (
          <Card key={order.id} className="shadow-soft">
            <CardContent className="space-y-4 py-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-display text-base font-semibold">{order.order_number}</p>
                  <p className="text-sm text-muted-foreground">
                    {order.customer_name} · {order.customer_phone}
                  </p>
                  <p className="text-xs text-muted-foreground">{order.delivery_address}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold">{formatFcfa(order.total_amount)}</p>
                  <p className="text-xs text-muted-foreground">
                    Commission 5% : {formatFcfa(order.commission_amount)}
                  </p>
                  <Badge
                    variant={order.payment_status === "paye" ? "default" : "secondary"}
                    className="mt-1 text-[10px]"
                  >
                    {PAYMENT_STATUS_LABELS[order.payment_status]}
                  </Badge>
                </div>
              </div>

              <ul className="rounded-lg bg-secondary/60 p-3 text-sm">
                {(order.order_items ?? []).map((item) => (
                  <li key={item.id} className="flex justify-between py-0.5">
                    <span>
                      {item.quantity} × {item.product_name}
                    </span>
                    <span>{formatFcfa(item.unit_price * item.quantity)}</span>
                  </li>
                ))}
              </ul>

              <div className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground">Statut</span>
                <Select
                  value={order.status}
                  onValueChange={(value) =>
                    mutation.mutate({ id: order.id, status: value as (typeof STATUSES)[number] })
                  }
                >
                  <SelectTrigger className="w-44">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {ORDER_STATUS_LABELS[s]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        ))}
        {orders.length === 0 && !ordersQuery.isLoading && (
          <Card className="py-12 text-center shadow-soft">
            <CardContent>
              <p className="text-sm text-muted-foreground">Aucune commande pour ce filtre.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </AppShell>
  );
}
