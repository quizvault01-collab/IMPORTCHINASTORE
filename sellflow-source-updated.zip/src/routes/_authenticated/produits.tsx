import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { deleteProduct, listMyProducts, saveProduct } from "@/lib/sellflow.functions";
import { formatFcfa } from "@/lib/slug";
import { Plus, Pencil, Trash2, ImageOff } from "lucide-react";

export const Route = createFileRoute("/_authenticated/produits")({
  head: () => ({
    meta: [
      { title: "Gérer mes produits — SellFlow" },
      {
        name: "description",
        content: "Ajoute tes produits, leurs prix en FCFA, leur stock et leurs photos.",
      },
      { property: "og:title", content: "Gérer mes produits — SellFlow" },
      { property: "og:description", content: "Catalogue produit de ta boutique SellFlow." },
    ],
  }),
  component: ProductsPage,
});

type Draft = {
  id?: string;
  name: string;
  description: string;
  price: string;
  stock_quantity: string;
  image_url: string;
  is_active: boolean;
};

const EMPTY: Draft = {
  name: "",
  description: "",
  price: "",
  stock_quantity: "0",
  image_url: "",
  is_active: true,
};

function ProductsPage() {
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState<Draft | null>(null);

  const productsQuery = useQuery({ queryKey: ["products"], queryFn: useServerFn(listMyProducts) });
  const save = useServerFn(saveProduct);
  const remove = useServerFn(deleteProduct);

  const saveMutation = useMutation({
    mutationFn: async (value: Draft) =>
      save({
        data: {
          id: value.id,
          name: value.name,
          description: value.description || null,
          price: Number(value.price || 0),
          stock_quantity: Number(value.stock_quantity || 0),
          image_url: value.image_url || null,
          is_active: value.is_active,
        },
      }),
    onSuccess: () => {
      toast.success("Produit enregistré");
      setDraft(null);
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => remove({ data: { id } }),
    onSuccess: () => {
      toast.success("Produit supprimé");
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const products = productsQuery.data ?? [];

  return (
    <AppShell>
      <div className="mb-6 flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Produits</h1>
          <p className="text-sm text-muted-foreground">{products.length} produit(s)</p>
        </div>
        <Button onClick={() => setDraft(EMPTY)}>
          <Plus /> Ajouter
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => (
          <Card key={product.id} className="overflow-hidden shadow-soft">
            <div className="flex h-40 items-center justify-center bg-secondary">
              {product.image_url ? (
                <img
                  src={product.image_url}
                  alt={product.name}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              ) : (
                <ImageOff className="size-8 text-muted-foreground" />
              )}
            </div>
            <CardContent className="space-y-2 py-4">
              <div className="flex items-start justify-between gap-2">
                <p className="font-semibold leading-tight">{product.name}</p>
                {!product.is_active && (
                  <span className="rounded bg-muted px-2 py-0.5 text-[10px]">Masqué</span>
                )}
              </div>
              <p className="text-lg font-bold text-primary">{formatFcfa(product.price)}</p>
              <p className="text-xs text-muted-foreground">Stock : {product.stock_quantity}</p>
              <div className="flex gap-2 pt-2">
                <Button
                  variant="soft"
                  size="sm"
                  onClick={() =>
                    setDraft({
                      id: product.id,
                      name: product.name,
                      description: product.description ?? "",
                      price: String(product.price),
                      stock_quantity: String(product.stock_quantity),
                      image_url: product.image_url ?? "",
                      is_active: product.is_active,
                    })
                  }
                >
                  <Pencil /> Modifier
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteMutation.mutate(product.id)}
                  className="text-destructive"
                >
                  <Trash2 />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {products.length === 0 && !productsQuery.isLoading && (
        <Card className="mt-6 py-12 text-center shadow-soft">
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Ton catalogue est vide. Ajoute ton premier produit pour pouvoir partager ta boutique.
            </p>
          </CardContent>
        </Card>
      )}

      <Dialog open={draft !== null} onOpenChange={(open) => !open && setDraft(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{draft?.id ? "Modifier le produit" : "Nouveau produit"}</DialogTitle>
          </DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nom</Label>
                <Input
                  id="name"
                  value={draft.name}
                  maxLength={100}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="price">Prix (FCFA)</Label>
                  <Input
                    id="price"
                    inputMode="numeric"
                    value={draft.price}
                    onChange={(e) =>
                      setDraft({ ...draft, price: e.target.value.replace(/\D/g, "") })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="stock">Stock</Label>
                  <Input
                    id="stock"
                    inputMode="numeric"
                    value={draft.stock_quantity}
                    onChange={(e) =>
                      setDraft({ ...draft, stock_quantity: e.target.value.replace(/\D/g, "") })
                    }
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="image">Lien de la photo</Label>
                <Input
                  id="image"
                  placeholder="https://..."
                  value={draft.image_url}
                  onChange={(e) => setDraft({ ...draft, image_url: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="desc">Description</Label>
                <Textarea
                  id="desc"
                  rows={3}
                  maxLength={1000}
                  value={draft.description}
                  onChange={(e) => setDraft({ ...draft, description: e.target.value })}
                />
              </div>
              <div className="flex items-center justify-between rounded-lg border border-border p-3">
                <Label htmlFor="active">Visible dans la boutique</Label>
                <Switch
                  id="active"
                  checked={draft.is_active}
                  onCheckedChange={(v) => setDraft({ ...draft, is_active: v })}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDraft(null)}>
              Annuler
            </Button>
            <Button
              disabled={!draft?.name || saveMutation.isPending}
              onClick={() => draft && saveMutation.mutate(draft)}
            >
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
