import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getMyVendor, saveVendor } from "@/lib/sellflow.functions";
import { CATEGORIES, CATEGORY_LABELS, slugify } from "@/lib/slug";

export const Route = createFileRoute("/_authenticated/ma-boutique")({
  head: () => ({
    meta: [
      { title: "Personnaliser ma boutique — SellFlow" },
      {
        name: "description",
        content: "Nom, slug, logo, bannière, couleur et opérateur Mobile Money de ta boutique.",
      },
      { property: "og:title", content: "Personnaliser ma boutique — SellFlow" },
      {
        property: "og:description",
        content: "Configure l'identité de ta boutique SellFlow en quelques minutes.",
      },
    ],
  }),
  component: ShopSettingsPage,
});

function ShopSettingsPage() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const vendorQuery = useQuery({ queryKey: ["vendor"], queryFn: useServerFn(getMyVendor) });
  const save = useServerFn(saveVendor);

  const [form, setForm] = useState({
    shop_name: "",
    shop_slug: "",
    owner_name: "",
    owner_phone: "",
    category: "autre",
    description: "",
    logo_url: "",
    banner_url: "",
    brand_color: "#0E7A5F",
    mobile_money_operator: "" as "" | "airtel" | "moov",
  });
  const [slugTouched, setSlugTouched] = useState(false);

  useEffect(() => {
    const v = vendorQuery.data;
    if (!v) return;
    setSlugTouched(true);
    setForm({
      shop_name: v.shop_name,
      shop_slug: v.shop_slug,
      owner_name: v.owner_name ?? "",
      owner_phone: v.owner_phone ?? "",
      category: v.category ?? "autre",
      description: v.description ?? "",
      logo_url: v.logo_url ?? "",
      banner_url: v.banner_url ?? "",
      brand_color: v.brand_color ?? "#0E7A5F",
      mobile_money_operator: (v.mobile_money_operator ?? "") as "" | "airtel" | "moov",
    });
  }, [vendorQuery.data]);

  const mutation = useMutation({
    mutationFn: async () => {
      const ref = typeof window !== "undefined" ? localStorage.getItem("sellflow_ref") : null;
      return save({
        data: {
          shop_name: form.shop_name.trim(),
          shop_slug: form.shop_slug || slugify(form.shop_name),
          owner_name: form.owner_name.trim(),
          owner_phone: form.owner_phone.trim(),
          category: form.category,
          description: form.description.trim() || null,
          logo_url: form.logo_url.trim() || null,
          banner_url: form.banner_url.trim() || null,
          brand_color: form.brand_color,
          mobile_money_operator: form.mobile_money_operator || null,
          ref,
        },
      });
    },
    onSuccess: () => {
      toast.success("Boutique enregistrée");
      queryClient.invalidateQueries({ queryKey: ["vendor"] });
      navigate({ to: "/tableau-de-bord" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const slug = form.shop_slug || slugify(form.shop_name);

  return (
    <AppShell>
      <h1 className="mb-6 text-2xl font-bold">Ma boutique</h1>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Informations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="shop_name">Nom de la boutique</Label>
              <Input
                id="shop_name"
                maxLength={60}
                value={form.shop_name}
                onChange={(e) => {
                  const shop_name = e.target.value;
                  setForm((f) => ({
                    ...f,
                    shop_name,
                    shop_slug: slugTouched ? f.shop_slug : slugify(shop_name),
                  }));
                }}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="slug">Adresse de la boutique</Label>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">/boutique/</span>
                <Input
                  id="slug"
                  value={form.shop_slug}
                  onChange={(e) => {
                    setSlugTouched(true);
                    setForm((f) => ({ ...f, shop_slug: slugify(e.target.value) }));
                  }}
                />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="owner_name">Nom du responsable</Label>
                <Input
                  id="owner_name"
                  maxLength={80}
                  value={form.owner_name}
                  onChange={(e) => setForm({ ...form, owner_name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner_phone">Téléphone (WhatsApp)</Label>
                <Input
                  id="owner_phone"
                  placeholder="+241 ..."
                  maxLength={30}
                  value={form.owner_phone}
                  onChange={(e) => setForm({ ...form, owner_phone: e.target.value })}
                />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Catégorie</Label>
                <Select
                  value={form.category}
                  onValueChange={(v) => setForm({ ...form, category: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {CATEGORY_LABELS[c]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Opérateur Mobile Money</Label>
                <Select
                  value={form.mobile_money_operator}
                  onValueChange={(v) =>
                    setForm({ ...form, mobile_money_operator: v as "airtel" | "moov" })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choisir" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="airtel">Airtel Money (via GeniusPay)</SelectItem>
                    <SelectItem value="moov">Moov Money (via K-PAY, bientôt)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                rows={3}
                maxLength={500}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="logo">Lien du logo</Label>
                <Input
                  id="logo"
                  value={form.logo_url}
                  onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="banner">Lien de la bannière</Label>
                <Input
                  id="banner"
                  value={form.banner_url}
                  onChange={(e) => setForm({ ...form, banner_url: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="color">Couleur de la boutique</Label>
              <input
                id="color"
                type="color"
                className="h-10 w-20 cursor-pointer rounded border border-input bg-background"
                value={form.brand_color}
                onChange={(e) => setForm({ ...form, brand_color: e.target.value })}
              />
            </div>

            <Button
              className="w-full"
              disabled={form.shop_name.trim().length < 2 || mutation.isPending}
              onClick={() => mutation.mutate()}
            >
              Enregistrer ma boutique
            </Button>
          </CardContent>
        </Card>

        <Card className="h-fit shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Aperçu</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div
              className="flex h-24 items-end rounded-lg p-3"
              style={{ backgroundColor: form.brand_color }}
            >
              <span className="font-display text-sm font-bold text-white drop-shadow">
                {form.shop_name || "Ma boutique"}
              </span>
            </div>
            <p className="break-all text-xs text-muted-foreground">/boutique/{slug || "..."}</p>
            {!form.mobile_money_operator && (
              <p className="rounded-md bg-warning/15 p-2 text-xs">
                Choisis un opérateur Mobile Money pour pouvoir recevoir des commandes.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
