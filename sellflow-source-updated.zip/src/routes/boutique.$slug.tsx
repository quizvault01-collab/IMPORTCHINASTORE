import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { getShopBySlug, placeOrder } from "@/lib/shop.functions";
import { formatFcfa } from "@/lib/slug";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ShoppingCart, Minus, Plus, ImageOff, CheckCircle2 } from "lucide-react";

type ShopProduct = {
  id: string;
  name: string;
  description: string | null;
  price: number;
  stock_quantity: number;
  image_url: string | null;
};

type ShopVendor = {
  id: string;
  shop_name: string;
  shop_slug: string;
  owner_name: string | null;
  category: string | null;
  description: string | null;
  logo_url: string | null;
  banner_url: string | null;
  brand_color: string | null;
  mobile_money_operator: string | null;
  status: string | null;
};

type ShopData = { vendor: ShopVendor; products: ShopProduct[] };

export const Route = createFileRoute("/boutique/$slug")({
  loader: async ({ params }): Promise<ShopData> => {
    const shop = (await getShopBySlug({ data: { slug: params.slug } })) as ShopData | null;
    if (!shop) throw notFound();
    return shop;
  },

  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Boutique introuvable — SellFlow" }, { name: "robots", content: "noindex" }],
      };
    }
    const { vendor } = loaderData;
    const description =
      vendor.description ?? `Commande chez ${vendor.shop_name} et paie par Mobile Money.`;
    return {
      meta: [
        { title: `${vendor.shop_name} — Boutique en ligne | SellFlow` },
        { name: "description", content: description.slice(0, 155) },
        { property: "og:title", content: `${vendor.shop_name} — SellFlow` },
        { property: "og:description", content: description.slice(0, 155) },
        ...(vendor.banner_url?.startsWith("https://")
          ? [
              { property: "og:image", content: vendor.banner_url },
              { name: "twitter:image", content: vendor.banner_url },
            ]
          : []),
      ],
    };
  },
  errorComponent: () => <ShopMessage title="Cette boutique n'a pas pu être chargée" />,
  notFoundComponent: () => <ShopMessage title="Cette boutique n'existe pas" />,
  component: ShopPage,
});

function ShopMessage({ title }: { title: string }) {
  return (
    <div className="flex min-h-screen items-center justify-center px-4 text-center">
      <div>
        <h1 className="text-xl font-semibold">{title}</h1>
        <Link to="/" className="mt-4 inline-block text-sm text-primary underline">
          Retour à SellFlow
        </Link>
      </div>
    </div>
  );
}

function ShopPage() {
  const { vendor, products } = Route.useLoaderData() as ShopData;
  const [cart, setCart] = useState<Record<string, number>>({});
  const [open, setOpen] = useState(false);
  const [done, setDone] = useState<{ order_number: string } | null>(null);
  const [form, setForm] = useState({
    customer_name: "",
    customer_phone: "",
    delivery_address: "",
    note: "",
  });

  const submit = useServerFn(placeOrder);
  const lines = useMemo(
    () =>
      products
        .filter((p) => cart[p.id])
        .map((p) => ({ ...p, quantity: cart[p.id], subtotal: p.price * cart[p.id] })),
    [cart, products],
  );
  const total = lines.reduce((s, l) => s + l.subtotal, 0);

  const mutation = useMutation({
    mutationFn: async () =>
      submit({
        data: {
          shopSlug: vendor.shop_slug,
          customer_name: form.customer_name.trim(),
          customer_phone: form.customer_phone.trim(),
          delivery_address: form.delivery_address.trim(),
          note: form.note.trim() || null,
          operator: (vendor.mobile_money_operator ?? "airtel") as "airtel" | "moov",
          items: lines.map((l) => ({ product_id: l.id, quantity: l.quantity })),
        },
      }),
    onSuccess: (data) => {
      setDone({ order_number: data.order_number });
      setCart({});
      setOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setQty = (id: string, delta: number) =>
    setCart((c) => {
      const next = Math.max(0, (c[id] ?? 0) + delta);
      const copy = { ...c };
      if (next === 0) delete copy[id];
      else copy[id] = next;
      return copy;
    });

  const accent = vendor.brand_color ?? "#0E7A5F";

  return (
    <div className="min-h-screen bg-background pb-24">
      <div
        className="h-40 bg-cover bg-center md:h-56"
        style={{
          backgroundColor: accent,
          backgroundImage: vendor.banner_url ? `url(${vendor.banner_url})` : undefined,
        }}
      />
      <div className="mx-auto max-w-5xl px-4">
        <div className="-mt-10 flex items-end gap-4">
          <div
            className="flex size-20 shrink-0 items-center justify-center overflow-hidden rounded-2xl border-4 border-background bg-secondary"
            style={{ backgroundColor: vendor.logo_url ? undefined : accent }}
          >
            {vendor.logo_url ? (
              <img src={vendor.logo_url} alt={vendor.shop_name} className="size-full object-cover" />
            ) : (
              <span className="font-display text-2xl font-bold text-white">
                {vendor.shop_name.charAt(0)}
              </span>
            )}
          </div>
          <div className="pb-1">
            <h1 className="font-display text-2xl font-bold">{vendor.shop_name}</h1>
            {vendor.owner_name && (
              <p className="text-sm text-muted-foreground">Par {vendor.owner_name}</p>
            )}
          </div>
        </div>
        {vendor.description && (
          <p className="mt-4 max-w-2xl text-sm text-muted-foreground">{vendor.description}</p>
        )}

        {done && (
          <Card className="mt-6 border-primary/40 bg-primary/5">
            <CardContent className="flex items-start gap-3 py-5">
              <CheckCircle2 className="mt-0.5 size-5 text-primary" />
              <div>
                <p className="font-semibold">Commande enregistrée : {done.order_number}</p>
                <p className="text-sm text-muted-foreground">
                  Tu vas recevoir une demande de paiement Mobile Money sur ton téléphone. Le vendeur
                  te contactera pour la livraison.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <h2 className="mt-8 text-lg font-semibold">Produits</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden shadow-soft">
              <div className="flex h-44 items-center justify-center bg-secondary">
                {product.image_url ? (
                  <img
                    src={product.image_url}
                    alt={product.name}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <ImageOff className="size-8 text-muted-foreground" />
                )}
              </div>
              <CardContent className="space-y-2 py-4">
                <p className="font-semibold leading-tight">{product.name}</p>
                {product.description && (
                  <p className="line-clamp-2 text-xs text-muted-foreground">
                    {product.description}
                  </p>
                )}
                <p className="font-display text-lg font-bold" style={{ color: accent }}>
                  {formatFcfa(product.price)}
                </p>
                {product.stock_quantity <= 0 ? (
                  <p className="text-xs text-destructive">Rupture de stock</p>
                ) : cart[product.id] ? (
                  <div className="flex items-center gap-3">
                    <Button variant="soft" size="icon" onClick={() => setQty(product.id, -1)}>
                      <Minus />
                    </Button>
                    <span className="font-semibold">{cart[product.id]}</span>
                    <Button
                      variant="soft"
                      size="icon"
                      disabled={cart[product.id] >= product.stock_quantity}
                      onClick={() => setQty(product.id, 1)}
                    >
                      <Plus />
                    </Button>
                  </div>
                ) : (
                  <Button className="w-full" onClick={() => setQty(product.id, 1)}>
                    Ajouter au panier
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
        {products.length === 0 && (
          <p className="py-12 text-center text-sm text-muted-foreground">
            Cette boutique n'a pas encore de produits en ligne.
          </p>
        )}

        <footer className="mt-16 border-t border-border py-6 text-center text-xs text-muted-foreground">
          Boutique propulsée par{" "}
          <Link to="/" className="font-semibold text-primary">
            SellFlow
          </Link>
        </footer>
      </div>

      {lines.length > 0 && (
        <div className="fixed inset-x-0 bottom-0 border-t border-border bg-background/95 p-3 backdrop-blur">
          <div className="mx-auto flex max-w-5xl items-center justify-between gap-3">
            <div>
              <p className="text-xs text-muted-foreground">
                {lines.reduce((s, l) => s + l.quantity, 0) } article(s)
              </p>
              <p className="font-display text-lg font-bold">{formatFcfa(total)}</p>
            </div>
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button size="lg">
                  <ShoppingCart /> Commander
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-md">
                <SheetHeader>
                  <SheetTitle>Finaliser la commande</SheetTitle>
                </SheetHeader>
                <div className="space-y-4 p-4">
                  <div className="space-y-1 rounded-lg bg-secondary p-3 text-sm">
                    {lines.map((l) => (
                      <div key={l.id} className="flex justify-between">
                        <span className="truncate">
                          {l.quantity} × {l.name}
                        </span>
                        <span>{formatFcfa(l.subtotal)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between border-t border-border pt-2 font-semibold">
                      <span>Total</span>
                      <span>{formatFcfa(total)}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cname">Nom complet</Label>
                    <Input
                      id="cname"
                      maxLength={80}
                      value={form.customer_name}
                      onChange={(e) => setForm({ ...form, customer_name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cphone">Numéro Mobile Money</Label>
                    <Input
                      id="cphone"
                      placeholder="+241 ..."
                      maxLength={30}
                      value={form.customer_phone}
                      onChange={(e) => setForm({ ...form, customer_phone: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="caddr">Adresse de livraison</Label>
                    <Input
                      id="caddr"
                      maxLength={300}
                      value={form.delivery_address}
                      onChange={(e) => setForm({ ...form, delivery_address: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cnote">Note (facultatif)</Label>
                    <Textarea
                      id="cnote"
                      rows={2}
                      maxLength={500}
                      value={form.note}
                      onChange={(e) => setForm({ ...form, note: e.target.value })}
                    />
                  </div>

                  <Button
                    className="w-full"
                    size="lg"
                    disabled={
                      mutation.isPending ||
                      form.customer_name.trim().length < 2 ||
                      form.customer_phone.trim().length < 6 ||
                      form.delivery_address.trim().length < 3
                    }
                    onClick={() => mutation.mutate()}
                  >
                    Payer {formatFcfa(total)} par Mobile Money
                  </Button>
                  <p className="text-center text-xs text-muted-foreground">
                    Paiement sécurisé. Aucun frais supplémentaire pour l'acheteur.
                  </p>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      )}
    </div>
  );
}
