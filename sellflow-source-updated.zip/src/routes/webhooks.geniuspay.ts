import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { verifyGeniusPaySignature } from "@/lib/payments/gateway.server";

/**
 * Endpoint appelé par GeniusPay pour confirmer (ou infirmer) un paiement de façon
 * asynchrone — indispensable car le paiement Mobile Money n'est pas instantané
 * (le client doit valider sur son téléphone après l'initiation).
 *
 * À configurer dans le dashboard GeniusPay : URL = https://<ton-domaine>/webhooks/geniuspay
 */
export const Route = createFileRoute("/webhooks/geniuspay")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rawBody = await request.text();
        const signature = request.headers.get("x-geniuspay-signature");

        if (!verifyGeniusPaySignature(rawBody, signature)) {
          console.warn("[webhook][geniuspay] signature invalide ou absente — requête ignorée");
          return new Response(JSON.stringify({ error: "invalid_signature" }), { status: 401 });
        }

        let payload: {
          event_id?: string;
          reference?: string;
          status?: "completed" | "failed" | "pending";
          metadata?: { order_id?: string };
        };
        try {
          payload = JSON.parse(rawBody);
        } catch {
          return new Response(JSON.stringify({ error: "invalid_json" }), { status: 400 });
        }

        const orderId = payload.metadata?.order_id;
        const eventId = payload.event_id ?? payload.reference;
        if (!orderId || !eventId) {
          return new Response(JSON.stringify({ error: "missing_order_or_event_id" }), { status: 400 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Idempotence : si cet événement a déjà été traité (GeniusPay peut renvoyer le
        // même webhook plusieurs fois), on ne le rejoue pas.
        const { error: insertError } = await supabaseAdmin.from("payment_webhook_events").insert({
          gateway: "geniuspay",
          gateway_event_id: eventId,
          order_id: orderId,
          payload,
        });
        if (insertError) {
          // Violation de contrainte unique = déjà traité, on répond 200 sans rien refaire.
          if (insertError.code === "23505") {
            return new Response(JSON.stringify({ ok: true, deduped: true }), { status: 200 });
          }
          console.error("[webhook][geniuspay] erreur enregistrement événement", insertError);
          return new Response(JSON.stringify({ error: "db_error" }), { status: 500 });
        }

        const newPaymentStatus =
          payload.status === "completed" ? "paye" : payload.status === "failed" ? "echoue" : "en_attente";
        const newOrderStatus = payload.status === "completed" ? "confirme" : "en_attente";

        const { error: updateError } = await supabaseAdmin
          .from("orders")
          .update({ payment_status: newPaymentStatus, status: newOrderStatus })
          .eq("id", orderId);

        if (updateError) {
          console.error("[webhook][geniuspay] erreur mise à jour commande", updateError);
          return new Response(JSON.stringify({ error: "db_error" }), { status: 500 });
        }

        return new Response(JSON.stringify({ ok: true }), { status: 200 });
      },
    },
  },
});
