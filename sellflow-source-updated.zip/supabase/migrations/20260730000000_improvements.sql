-- Améliorations : décrément de stock atomique, calcul d'affiliation dégressif,
-- support des webhooks de paiement (idempotence + traçabilité).

-- 1. Décrément atomique du stock (évite la race condition entre deux commandes simultanées)
CREATE OR REPLACE FUNCTION public.decrement_stock(_product_id UUID, _quantity INTEGER)
RETURNS BOOLEAN LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _updated INTEGER;
BEGIN
  UPDATE public.products
  SET stock_quantity = stock_quantity - _quantity
  WHERE id = _product_id AND stock_quantity >= _quantity;
  GET DIAGNOSTICS _updated = ROW_COUNT;
  RETURN _updated > 0;
END;
$$;
GRANT EXECUTE ON FUNCTION public.decrement_stock(UUID, INTEGER) TO service_role;

-- Inverse de decrement_stock : remet le stock si le paiement échoue après réservation.
CREATE OR REPLACE FUNCTION public.increment_stock(_product_id UUID, _quantity INTEGER)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.products SET stock_quantity = stock_quantity + _quantity WHERE id = _product_id;
END;
$$;
GRANT EXECUTE ON FUNCTION public.increment_stock(UUID, INTEGER) TO service_role;

-- 2. Colonnes nécessaires au calcul d'affiliation dégressif
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS first_sale_at TIMESTAMPTZ;
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS early_rate NUMERIC NOT NULL DEFAULT 0.20;
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS late_rate NUMERIC NOT NULL DEFAULT 0.07;
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS early_period_months INTEGER NOT NULL DEFAULT 3;

-- 3. Fixe la date de première vente du vendeur (une seule fois)
CREATE OR REPLACE FUNCTION public.set_vendor_first_sale() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.payment_status = 'paye' AND (OLD.payment_status IS DISTINCT FROM 'paye') THEN
    UPDATE public.vendors
    SET first_sale_at = COALESCE(first_sale_at, now())
    WHERE id = NEW.vendor_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS orders_first_sale ON public.orders;
CREATE TRIGGER orders_first_sale AFTER UPDATE OF payment_status ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.set_vendor_first_sale();

-- 4. Calcule et enregistre la commission d'affiliation dégressive quand une commande passe "payée"
CREATE OR REPLACE FUNCTION public.compute_affiliate_commission() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _vendor RECORD;
  _affiliate RECORD;
  _months_since_first_sale INTEGER;
  _rate NUMERIC;
BEGIN
  IF NEW.payment_status <> 'paye' OR (OLD.payment_status IS NOT DISTINCT FROM 'paye') THEN
    RETURN NEW;
  END IF;

  SELECT * INTO _vendor FROM public.vendors WHERE id = NEW.vendor_id;
  IF _vendor.referred_by IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT * INTO _affiliate FROM public.affiliates WHERE id = _vendor.referred_by;
  IF _affiliate.id IS NULL THEN
    RETURN NEW;
  END IF;

  _months_since_first_sale := CASE
    WHEN _vendor.first_sale_at IS NULL THEN 0
    ELSE EXTRACT(YEAR FROM AGE(now(), _vendor.first_sale_at)) * 12
       + EXTRACT(MONTH FROM AGE(now(), _vendor.first_sale_at))
  END;

  _rate := CASE
    WHEN _months_since_first_sale < _affiliate.early_period_months THEN _affiliate.early_rate
    ELSE _affiliate.late_rate
  END;

  INSERT INTO public.affiliate_commissions (affiliate_id, vendor_id, order_id, amount, rate, period)
  VALUES (
    _affiliate.id,
    _vendor.id,
    NEW.id,
    ROUND(NEW.commission_amount * _rate),
    _rate,
    date_trunc('month', now())::date
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS orders_affiliate_commission ON public.orders;
CREATE TRIGGER orders_affiliate_commission AFTER UPDATE OF payment_status ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.compute_affiliate_commission();

-- 5. Traçabilité et idempotence des webhooks de paiement (un même événement fournisseur
--    ne doit jamais être traité deux fois, même si le webhook est renvoyé plusieurs fois).
CREATE TABLE IF NOT EXISTS public.payment_webhook_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  gateway TEXT NOT NULL,
  gateway_event_id TEXT NOT NULL,
  order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
  payload JSONB NOT NULL,
  processed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (gateway, gateway_event_id)
);
GRANT ALL ON public.payment_webhook_events TO service_role;
ALTER TABLE public.payment_webhook_events ENABLE ROW LEVEL SECURITY;
-- Aucune policy publique : uniquement accessible via service_role (backend), jamais côté client.

CREATE INDEX IF NOT EXISTS idx_affiliate_commissions_affiliate ON public.affiliate_commissions(affiliate_id, period);
