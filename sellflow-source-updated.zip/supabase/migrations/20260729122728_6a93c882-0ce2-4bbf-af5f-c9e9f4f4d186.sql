
DROP POLICY "orders_public_insert" ON public.orders;
DROP POLICY "order_items_public_insert" ON public.order_items;
REVOKE INSERT ON public.orders FROM anon;
REVOKE INSERT ON public.order_items FROM anon;
REVOKE INSERT ON public.orders FROM authenticated;
REVOKE USAGE ON SEQUENCE public.order_number_seq FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.owns_vendor(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.owns_vendor(UUID) TO authenticated;
